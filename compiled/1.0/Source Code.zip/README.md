### Flappy Hole ###

Author: CosmicBit128

Description:
Falppy Hole is a fun and addictive game where you navigate through pipes. Fly into one pipe and out of another to score points and see how far you can go!

Credits:
- Graphics: Resources obtained from spriters-resource.com (artist: Superjustinbros)
- Audio: Sounds obtained from sounds-resource.com (artist: SuperTVGRFan18496)

Usage Rights:
The resources used in this project, including graphics and audio, were obtained from spriters-resource.com and sounds-resource.com and are used with permission. Proper credit to the original artists is provided within the software.

Non-Commercial Use:
This software is provided for non-commercial use only. You may not sell, distribute, or otherwise exploit this software for profit.

Open Source:
This software is open source and distributed under the MIT license. The source code is available for inspection and modification on [FlappyHole](https://github.com/CosmicBit128/FlappyHole).

No Warranty:
This software is provided "as is" without warranty of any kind, express or implied. The creators of this software shall not be liable for any damages arising from the use of this software.

Privacy Policy:
This software does not collect any kind of data from users. Your privacy is important, and no information is gathered or stored during gameplay. Feel confident knowing that your personal information remains private while enjoying Flappy Hole.
